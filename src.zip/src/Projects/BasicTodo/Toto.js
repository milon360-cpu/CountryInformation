import React from 'react';

const Toto = (props) => {
    return (
        <div>
            <h1>{props.todo}</h1>
        </div>
    );
};

export default Toto;