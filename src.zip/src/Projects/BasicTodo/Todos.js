import React from 'react';
import Toto from './Toto';
const Todos = (props) => {
    return (
        <div>
            {
                props.todo.map((todo,index)=>
                {
                    return <Toto todo = {todo} key={index}></Toto>
                })
            }
        </div>
    );
};

export default Todos;