import React,{useState} from 'react';
import NewTodos from './NewTodos';
import Todos from './Todos';
const Home = () => {
    const damiTodo = ['todo1','todo2']
    const [todo,setTodo] = useState(damiTodo);
    const handelTodo = (passTodo)=>
    {
      setTodo([...todo,passTodo]);
    }
    return (
        <div>
           <NewTodos handelTodo = {handelTodo}></NewTodos>
           <Todos todo = {todo}></Todos>
        </div>
    );
};

export default Home;