import React,{useState} from 'react';

const NewTodos = (props) => {
    const [todo,setTodo] = useState('');
 const handelTodo = (e)=>
 {
   setTodo(e.target.value);
 }
 const submitTodo = (e)=>
 {
   props.handelTodo(todo);
   e.preventDefault();
 }
    return (
        <div>
            <form action="" onSubmit={submitTodo}>
                <label htmlFor="todo">Add Todo: </label>
                <input type="text" name="todo" id="" onChange={handelTodo} value={todo}/>
                <button>Add Todo</button>
            </form>
        </div>
    );
};

export default NewTodos;