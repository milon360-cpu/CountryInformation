import React from 'react';
import Todo from './Todo';
import './Todos.css'
import { v4 as uuidv4 } from 'uuid';
const Todos = (props) => {
    return (
      <section className='todo-container'>
          {
           
             props.todo.map((todo)=>
             {
                 return <Todo todo = {todo} removeTodo = {props.removeTodo} uniqueId = {todo.id} key={todo.key}></Todo>
               
             })
            
          }        
      </section>
    );
};

export default Todos;