import React,{useState} from 'react';
import './NewTodos.css'
const NewTodos = (props) => {
    const [todo,setTodo] = useState({title:'',des:''})
    const handelChange =(e)=>
    {
       setTodo({...todo, [e.target.name]:e.target.value});
    }
    const handelSubmit =(e)=>
    {
      props.handelTodo(todo);   
      e.preventDefault();
    
    
    }
    return (
        <div className='form-container'>
            <h1 className='todo-header'>Add Your Todo</h1>
            <hr />
            <form action="" onSubmit={handelSubmit}>
                <div className="title-container">
                    <label htmlFor="title">Title</label>
                    <input type="text"  name='title' placeholder='Title' onChange={handelChange} maxLength={30}/>
                </div>
                <div className="description-container">
                    <label htmlFor="des">Description</label>
                    <textarea name="des" id="" cols="30" rows="10" placeholder='Description Here' onChange={handelChange} maxLength={70} ></textarea>
                </div>
                <div className="btn-container">
                   <button>Add</button>
                </div>
              
            </form>
        </div>
    );
};

export default NewTodos;