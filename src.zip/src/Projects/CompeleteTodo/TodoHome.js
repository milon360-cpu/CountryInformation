import React,{useState} from 'react';
import NewTodos from './NewTodos';
import Todos from './Todos';
import { v4 as uuidv4 } from 'uuid';
import './TodoHome.css'
const TodoHome = () => {
     const [damiTodo, setDamiTodo] = useState([]);
     const getDamiTodo =(todo)=>
     {
       setDamiTodo([...damiTodo,{todo,id:uuidv4()}]);
    
     }
     const removeTodo = (id_)=>
     {
        setDamiTodo(()=>
        {
            return damiTodo.filter((x)=>x.id !== id_);
        })
      
     }
    return (
        <div className='all-todo-are-here'>
            <NewTodos handelTodo = {getDamiTodo} key = {uuidv4()}></NewTodos>
            <Todos todo = {damiTodo} removeTodo = {removeTodo} key={uuidv4()}></Todos>
        </div>
    );
};

export default TodoHome;