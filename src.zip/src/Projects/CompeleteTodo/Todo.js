import React from 'react';
import './Todo.css';
const Todo = (props) => {
    
    const {title,des} = props.todo.todo;
    const todoId = props.uniqueId;
    
    const deleteTodo = (id)=>
    {
        props.removeTodo(id);
    }
    return (
        <article className='tod-container'>
         <div className='todo-details'>
            <h2>{title}</h2>
            <p>{des}</p>
         </div>
         <div className="trash">
            <button onClick={()=>
            {
                deleteTodo(todoId);
            }}> <i className='fa fa-trash fa-2x'></i></button>          
         </div>
         
        </article>
      
    );
};

export default Todo;