import React,{useState} from 'react';
import FAQ from './FAQ';
import faqData from './FaqData.json';
import './FAQS.css'
const FAQS = () => {
    const [faq,setFaq] = useState(faqData);
    return (
        <div>
            <div className="faq-home-section">
                {
                    faq.map((data)=>
                    {
                       return <FAQ key={data.id} {...data}></FAQ>
                    })
                }
            </div>
        </div>
    );
};

export default FAQS;