import React,{useState} from 'react';
import './FAQ.css'
import  Fade  from 'react-reveal/Fade';
import Slide from 'react-reveal/Slide';
const FAQ = ({id,title,des}) => {
const [toggle,setToggle] = useState(false)
    return (
        <div>
             <div className="faq-container">
                <h2>{title}</h2>
                <button onClick={()=>
                {
                    setToggle(!toggle);
                }}>{toggle ? '-':'+'}</button>

             </div>
              
             <div className="des-container">               
               {toggle &&(<p>{des}</p>)}    
             </div>         
        </div>
    );
};

export default FAQ;