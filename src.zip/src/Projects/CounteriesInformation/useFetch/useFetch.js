import React,{useState,useEffect} from 'react';

const useFetch = (url) => {
    const [data,setData] = useState(null)
    const [isLoading,setIsLoading] = useState(true);
    const [error, setError] = useState(null);
    const [duplicateData,setDuplicateData] = useState(null)

    useEffect(()=>
    {
        fetch(url)
        .then((response)=>
        {
            if(!response.ok)
                throw Error("Loading Failed");
            else
            return response.json();
        })
        .then((data)=>
        {
            setData(data);
            setDuplicateData(data)
            setIsLoading(false);
        })
    },[url])
    return [data,isLoading,setData,duplicateData,setDuplicateData];
        
};

export default useFetch;