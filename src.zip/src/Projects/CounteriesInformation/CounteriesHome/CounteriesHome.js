import React,{useState,useEffect} from 'react';
import Counteres from '../Counteries/Counteries';
import SearchCoutery from '../SearchCountery/SearchCoutery';
import useFetch from './../useFetch/useFetch';
import './CounteriesHome.css'
const CounteriesHome = () => {
      const [data, setData] = useState([]);
      const [duplicateData, setduplicateData] = useState([]);
      const [isLoading, setIsLoading] = useState(true);
      const loadingMessage = 'Loading...';
      useEffect(()=>
      {
        fetch('https://restcountries.com/v3.1/all')
        .then((response)=> response.json())
        .then((data)=>
        {
            setData(data)
            setduplicateData(data);
            setIsLoading(false);
        })
      },[])

    const hadnelRemove = (countryName)=>
    {
        const newCountry = data.filter((data)=>
        {
            return data.name.common !== countryName;
        })
      setData(newCountry);
    }
    const onSearch = (searchedText)=>
    {
       let convertSearingText = searchedText.toLowerCase();
         const againSetNewCountry = duplicateData.filter((data)=>
         {
           let convertCountryName = data.name.common.toLowerCase();
           return convertCountryName.startsWith(convertSearingText);
         })
         setData(againSetNewCountry);
      
    }
    return (
        <div>
            <h1 className='country-header'>Country Information</h1>
             <SearchCoutery  onSearch = {onSearch}></SearchCoutery>
            { isLoading && <h1>{loadingMessage}</h1> }
            { data && <Counteres countriesData = {data} hadnelRemove = {hadnelRemove}></Counteres>}
           
        </div>
    );
};

export default CounteriesHome;