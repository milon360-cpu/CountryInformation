import React from 'react';
import './Countery.css'
const Countery = (props) => {
      const {name,flags,capital,region,population} = props;

      const onRemove =(countryName)=>
      {
          props.hadnelRemove(countryName);
      }
      
        return (
        <div className='country'>
            <img src={flags.png} alt=""/>
            <h2>Name : {name.common}</h2>
            <h4>Capital: {capital}</h4>
            <h4>Region : {region}</h4>
            <h4>population : {population}</h4>
            <button className='remove-btn'onClick={()=>
            {
                onRemove(name.common);
            }}>remove</button>
        </div>
    );
};

export default Countery;