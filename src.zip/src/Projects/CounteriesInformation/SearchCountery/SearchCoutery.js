import React,{useState,useEffect}from 'react';
import './SearchCoutery.css';
const SearchCoutery = (props) => {
     const [searchText, setSearchText] = useState("")
    const onHandelChange = (event)=>
    {
        setSearchText(event.target.value);
    }
    useEffect(()=>
    {
        props.onSearch(searchText)
    },[searchText]);
    return (
        <div className='search-container'>
            <input type="text" name='search' placeholder='Search here' onChange={onHandelChange} />
        </div>
    );
};

export default SearchCoutery;