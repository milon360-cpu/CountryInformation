import React from 'react';
import Counterie from  '../Cuntery/Countery';
import { v4 as uuidv4 } from 'uuid';
import './Counteries.css'
const Counteries = (props) => {
    const data = props.countriesData;
   
    return (
        <div className='country-container'>
         {
            data.map((data)=>
            {;
                return <Counterie {...data} hadnelRemove = {props.hadnelRemove} key = {uuidv4()}></Counterie>
            })
         }
            
        </div>
    );
};

export default Counteries;
