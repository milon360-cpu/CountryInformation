import logo from './logo.svg';
import './App.css';
import UniqueId from './Topics/UniqueId/UniqueId'
import NastedMaping from './Topics/NastedMaping/NastedMaping';
import ClassComponent from './Topics/ClassComponent/ClassComponent';
import UseState_ from './Topics/Hooks/UseState_';
import Form_ from './Topics/Form_/Form_';
import Parents from './Topics/PassDataChildToParents/Parents';
import Home from './Projects/BasicTodo/Home';
import TodoHome from './Projects/CompeleteTodo/TodoHome'
import Toggle from './Topics/Toggle/Toggle';
import FAQS from './Projects/FAQ/FAQS';
import UseEffect_ from './Topics/UseEffect_/UseEffect_';
import CounteriesHome from './Projects/CounteriesInformation/CounteriesHome/CounteriesHome';
function App() {
  return (
    <div className="App">
      {/* <UniqueId></UniqueId> */}
      {/* <NastedMaping></NastedMaping> */}
      {/* <ClassComponent name = "Milon Mondal"></ClassComponent> */}
      {/* <UseState_></UseState_> */}
      {/* <Form_ ></Form_> */}
      {/* <Parents></Parents> */}
      {/* <Home></Home> */}
      {/* <TodoHome></TodoHome> */}
      {/* <Toggle></Toggle> */}
      {/* <FAQS></FAQS> */}
      {/* <UseEffect_></UseEffect_> */}
      <CounteriesHome></CounteriesHome>
    </div>
  );
}

export default App;
