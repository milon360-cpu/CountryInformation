import React,{useState} from 'react';
import Child from './Child';

const Parents = () => {
    const [value,setValue] = useState('');
    const givenData= (passName)=>
    {
        setValue(passName);
    }
    return (
        <div>
           <Child name = 'Milon Mondal' sendData = {givenData}></Child>
          <h1>{value}</h1>
        </div>
    );
};

export default Parents;