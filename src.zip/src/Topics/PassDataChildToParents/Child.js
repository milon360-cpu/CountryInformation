import React from 'react';

const Child = (props) => {
    props.sendData("Milon Mondal Tapu");
    return (
        <div>
            <h1>{props.name}</h1>
        </div>
    );
};

export default Child;