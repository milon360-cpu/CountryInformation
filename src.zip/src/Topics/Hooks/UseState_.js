import React, { useState } from 'react';

const UseState_ = () => {
    const [additem,setitem] = useState(0);

    return (
        <div>
            <h1>Count :{additem}</h1>
            <button onClick={()=>
            {
                setitem(additem+1);
            }}>Add me</button>
        </div>
    );
};

export default UseState_;