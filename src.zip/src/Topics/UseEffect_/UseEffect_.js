import React,{useState} from 'react';
import { useEffect } from 'react';
import useFetch from './../CustomeHook/useFetch';

const UseEffect_ = () => {
     const {data,isLoading} = useFetch("https://jsonplaceholder.typicode.com/todos");
 
    const totoTitle = data && data.map((data)=>
    {
      return <h5 key={data.id}>{data.title}</h5>
    })
    const lodingMassage = <h1>Loading...</h1>
 
    return (
        <div>
            {isLoading && lodingMassage}
            {totoTitle}
        </div>
    );
};

export default UseEffect_;