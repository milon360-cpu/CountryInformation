import React,{useState,useEffect} from 'react';

const useFetch = (url) => {
    const [data,setData] = useState(null);
    const [isLoading,setLoading] = useState(true);
    
    useEffect(()=>
    {
        fetch(url)
       .then((response)=> response.json())
       .then((data)=>
       {
         setData(data)
         setLoading(false);
       });
    })
    return {data,isLoading}
};

export default useFetch;