import React,{useState} from 'react';
import Fade from 'react-reveal/Fade';
import './Toggle.css'
const Toggle = () => {
    const [toggle,setToggle] = useState(true);
    return (
        <div>
           <div className="container">
            { toggle &&(
                <Fade >
               <p >
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Explicabo ducimus corporis non, sunt esse perferendis consectetur porro mollitia exercitationem nisi illo nemo, adipisci atque quaerat temporibus fugit qui quo? Aperiam qui mollitia asperiores facilis, aliquid incidunt error ducimus fugiat accusamus!
              </p>
              </Fade>
            )}
              
              <button onClick={()=>
                            {
                               setToggle(!toggle);
                            }}>
                  {toggle ? "Hide":"Show"}           
                 </button>
           </div>
        </div>
    );
};

export default Toggle;