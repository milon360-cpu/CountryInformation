import React from 'react';
import { v4 as uuidv4 } from 'uuid';
const NastedMaping = () => {
    const info = 
    [
        {
            name:"Milon Mondal",
            age:21,
            address:'Dhaka',
            phone:[{ph:'01771341302'},{office:'01954040096'}]
        },
        {
            name:"Tapu Mondal",
            age:21,
            address:'Faridpur',
            phone:[{ph:'01771341402'},{office:'01954040097'}]
        },
        {
            name:"Zamir Mondal",
            age:22,
            address:'Khilgoan',
            phone:[{ph:'01771341502'},{office:'01954040098'}]
        },
        {
            name:"Amir Mondal",
            age:45,
            address:'Comilla',
            phone:[{ph:'01771341602'},{office:'01954040099'}]
        }
    ]
    return (
        <div>
            {
                info.map((data,index)=>
                {
                    const {name,age,address,phone} = data;
                    return(
                        <article key={index}>
                            <h1>{name}</h1>
                            <h2>{age}</h2>
                            <h3>{address}</h3>
                            <div>
                                {
                                    phone.map((phone)=>
                                    {
                                        const{ph,office} = phone;
                                        return(
                                            <article key={uuidv4()}>
                                                <h1>{ph}</h1>
                                                <h2>{office}</h2>
                                            </article>
                                        )
                                    })
                                }
                            </div>
                        </article>
                    )
                })
            }
        </div>
    );
};

export default NastedMaping;