import React from 'react';
import { v4 as uuidv4 } from 'uuid';
const UniqueId = () => {
    const info = 
    [
        {
            name:"Milon Mondal",
            id:uuidv4(),
            age:21,
            address:'Dhaka'
        },
        {
            name:"Tapu Mondal",
            id:uuidv4(),
            age:21,
            address:'Faridpur'
        },
        {
            name:"Zamir Mondal",
            id:uuidv4(),
            age:22,
            address:'Khilgoan'
        },
        {
            name:"Amir Mondal",
            id:uuidv4(),
            age:45,
            address:'Comilla'
        }
    ]
    return (
        <div>
            {
                info.map((data)=>
                {
                    const {name,id,age,address} = data;
                    return (
                        <article key={id}>
                            <h1>{name}</h1>
                            <h2>{age}</h2>
                            <h3>{address}</h3>
                        </article>
                    )
                })
            }
        </div>
    );
};

export default UniqueId;