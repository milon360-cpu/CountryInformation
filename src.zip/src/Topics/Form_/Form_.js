import React,{useState} from 'react';
 
const Form_ = () => {
    const [user,setUser] = useState({name:'',email:'',password:''});
    const formHandel = (e)=>
    {
       setUser({...user,[e.target.name]:e.target.value});
    }
    const submitHandel = (e)=>
    {
       console.log(user);
        e.preventDefault();
    }
    return (
        <div>
            <h1>Registration Form</h1>
            <form action="" onSubmit={submitHandel}>
                <label htmlFor="name">User Name</label>
                <input type="text" name="name" id="userName" onChange={formHandel}/><br />
                <label htmlFor="email">Email</label>
                <input type="email" name="email" id="email" onChange={formHandel}/><br />
                <label htmlFor="password">Password</label>
                <input type="password" name="password" id="userPassword" onChange={formHandel} />
                <button type='submit'>Submit</button>
            </form>
        </div>
    );
};

export default Form_;